package com.Course02;

public class StartClient {
    public static void main(String[] args) {
        Client client = new Client();
    }
}

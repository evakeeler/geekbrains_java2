package com.Course02;

import java.net.Socket;
import java.io.*;
import java.util.Scanner;


public class Client {
    Socket socket;
    PrintWriter out;
    BufferedReader in;

    public Client() {
        Scanner scan = new Scanner(System.in);

        try {
            socket = new Socket("localhost", 8283);
        } catch (IOException e) {
            System.out.println("Ошибка сокета");
            e.printStackTrace();
        }

        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            System.out.println("Введите ваш ник:");
            out.println(scan.nextLine());

            ServerThreads serverThreads = new ServerThreads();
            serverThreads.start();

            String str = "";

            while (!str.equals("//exit")) {
                str = scan.nextLine();
                out.println(str);
            }
            serverThreads.Abort();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
    }

    private void close() {
        try {
            in.close();
            out.close();
            socket.close();
        } catch (Exception e) {
            System.out.println("Ошибка при закрытии! ");
            e.printStackTrace();
        }
    }

    private class ServerThreads extends Thread {
        private boolean stoped;

        public void Abort() {
            stoped = true;
        }

        @Override
        public void run() {
            try {
                while (!stoped) {


                    String str = in.readLine();
                    System.out.println(str);
                }
            } catch (IOException e) {
                System.out.println("ServerThreads Ошибка получения сообщения");
                e.printStackTrace();
            }
        }
    }
}



package com.Course02;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;


public class Server {

    private List<Link> listLinks = Collections.synchronizedList(new ArrayList());
    private ServerSocket server;

    public Server() {
        try {
            server = new ServerSocket(8283);
            System.out.println("Сервер запущен");
            while (true) {
                Socket socket = server.accept();
                Date date = new Date();
                System.out.println("Новое подключение установлено " + date.toString());
                Link con = new Link(socket);
                listLinks.add(con);
                con.start();

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            closeAll();
        }
    }

    private void closeAll() {
        try {
            server.close();

            synchronized (listLinks) {
                Iterator<Link> iterator = listLinks.iterator();
                while (iterator.hasNext()) {
                    (iterator.next()).close();
                }
            }
        } catch (Exception e) {
            System.out.println("Ошибка при общем закрытии! " + e);
        }
    }


    private class Link extends Thread {
        private BufferedReader in;
        private PrintWriter out;
        private Socket socket;

        public String userName = "";

        public Link(Socket socket) {
            this.socket = socket;

            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

            } catch (IOException e) {
                e.printStackTrace();
                close();
            }
        }

        public void run() {
            try {
                userName = in.readLine();


                synchronized (listLinks) {
                    Iterator<Link> iter = listLinks.iterator();
                    while (iter.hasNext()) {
                        (iter.next()).out.println(userName + " - новенький ПРИШЕЛ");
                    }
                }


                String str = "";
                while (true) {
                    str = in.readLine();
                    if (str.equals("//exit")) break;

                    synchronized (listLinks) {
                        Iterator<Link> iterator = listLinks.iterator();
                        while (iterator.hasNext()) {
                            (iterator.next()).out.println(userName + ": " + str);
                        }
                    }

                }


                synchronized (listLinks) {
                    Iterator<Link> iterator = listLinks.iterator();
                    while (iterator.hasNext()) {
                        (iterator.next()).out.println(userName + " - ОТКЛЮЧИЛСЯ");
                    }
                }


            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                close();
            }
        }

        public void close() {
            try {

                in.close();
                out.close();
                socket.close();

                listLinks.remove(this);
                if (listLinks.size() == 0) {
                    Server.this.closeAll();
                    System.exit(0);
                }
            } catch (Exception e) {
                System.out.println("Ошибка при закрытии ! " + e);
            }
        }
    }

}



package com.Course02;

public class StartServer {
    public static void main(String[] args) {
        Server serv = new Server();
    }
}

package gb.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class ClientHandler {
    private Server server;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in;
    private ArrayList<String> blacklist;

    public String getNick() {
        return nick;
    }

    private String nick;
    private String permission;
    private final String killMsg = "Вас удалили из чата";

    public ClientHandler(Server server, Socket socket) {

        try {
            this.blacklist = new ArrayList<>();
            this.socket = socket;
            this.server = server;
            this.in = new DataInputStream(socket.getInputStream());
            this.out = new DataOutputStream(socket.getOutputStream());
            new Thread(() -> {
                try {
                    while (true) {
                        String str = in.readUTF();
                        if (str.startsWith("/auth")) {
                            String[] tokens = str.split(" ");
                            String newNick = AuthService.getNickByLoginAndPass(tokens[1], tokens[2]);
                            String perm = AuthService.getPermission(tokens[1]);
                            if (newNick != null) {
                                if (!server.isNickBusy(newNick)) {
                                    sendMsg("/authok");
                                    nick = newNick;
                                    permission = perm;
                                    blacklist = AuthService.getBlacklist(tokens[1]);
                                    server.subscribe(this);
                                    break;
                                } else {
                                    sendMsg("Учетная запись уже используется!");
                                }

                            } else {
                                sendMsg("Неверный логин/пароль");
                            }
                        }
                    }
                    while (true) {
                        String str = in.readUTF();
                        if (str.startsWith("/")) {
                            if (str.equals("/end")) {
                                out.writeUTF("/serverclosed");
                                break;
                            }
                            if (str.startsWith("/w")) {
                                String[] tokens = str.split(" ", 3);
                                server.sendPersonalMsg(this, tokens[1], tokens[2]);
                            }

                            if (str.startsWith("/q")) {
                                String[] tokens = str.split(" ", 3);
                                server.sendPrivateFormMsg(this, tokens[1], tokens[2]);
                            }

                            if (str.startsWith("/kill")) {
                                String[] tokens = str.split(" ", 2);
                                if (permission.equals("a")) {
                                    server.sendPersonalMsg(this, tokens[1], killMsg);
                                    try {
                                        Thread.sleep(2000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    out.writeUTF("/serverclosed");
                                    break;
                                }
                            }

                            if (str.startsWith("/addUser")) {
                                String[] tokens = str.split(" ", 5);
                                if (permission.equals("a")) {
                                    AuthService.addUser(tokens[1], tokens[2], tokens[3], tokens[4]);
                                    sendMsg("Вы создали пользователя логин:" + tokens[1] + " пароль:" + tokens[2] + " ник:" + tokens[3] + " доступ:" + tokens[4]);
                                }
                            }

                            if (str.startsWith("/blacklistadd ")) {
                                String[] tokens = str.split(" ");
                                blacklist.add(tokens[1]);
                                sendMsg("Вы добавили пользователя " + tokens[1] + " в черный список");
                                updateBlacklist();
                            }

                            if (str.startsWith("/updateBlacklist ")) {
                                updateBlacklist();
//
//                                String[] tokens = str.split(" ");
//                                blacklist.add(tokens[1]);
//                                sendMsg("Вы добавили пользователя " + tokens[1] + " в черный список");
                            }

                            if (str.startsWith("/history ")) {
                                StringBuilder stringBuilder = AuthService.getHistoryChat();
                                out.writeUTF(stringBuilder.toString());
                            }


                        } else {
                            AuthService.saveHistory(nick, str);
                            server.broadcastMsg(this, nick + ": " + str);
                        }

                        System.out.println("Client: " + str);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    server.unsubscribe(this);
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean checkBlackList(String nick) {
        return blacklist.contains(nick);
    }

    public void sendMsg(String msg) {
        try {
            out.writeUTF(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendFormMsg(String nickTo, String msg) {
        try {
            out.writeUTF("/qw " + nickTo + " " + msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateBlacklist() {
        String list = "/blacklist ";
        for (String s : blacklist) {
            list = list + s + " ";
        }
        try {
            out.writeUTF(list);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

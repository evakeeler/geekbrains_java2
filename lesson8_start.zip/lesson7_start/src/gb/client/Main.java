package gb.client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import gb.client.Controller;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        //Parent root = FXMLLoader.load(getClass().getResource("client.fxml"));
        Parent root = FXMLLoader.load(getClass().getResource("ChatForm2.fxml"));
        primaryStage.setTitle("2k18Chat");
        primaryStage.setScene(new Scene(root, 822, 530));
        primaryStage.show();
        //timeToAuthorize();
    }

    public void timeToAuthorize(){
        new Thread(() -> {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Controller controller = new Controller();
            if(!controller.getAuthorized()){
                System.exit(0);
            }
        }).start();

    }


    public static void main(String[] args) {
        launch(args);
    }
}

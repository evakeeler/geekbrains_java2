package gb.client;

import gb.server.ClientHandler;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.TextFlow;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

public class Controller {
    @FXML
    VBox vboxLogin;

    @FXML
    VBox vboxLeftMenu;

    @FXML
    VBox vboxChat;

    @FXML
    VBox vboxRightList;

    @FXML
    TextField msgField;
    @FXML
    TextField privTextField;

    @FXML
    TextArea chatArea;
    @FXML
    TextArea privTextArea;

    @FXML
    TextField loginTextField;



    @FXML
    PasswordField passTextField;

    @FXML
    ListView clientListRight;

    @FXML
    ListView blackList;

    @FXML
    Label fromNickLabel;
    @FXML
    Label toNickLabel;

    private boolean isAuthorized;
    Socket socket;
    DataInputStream in;
    DataOutputStream out;

    final String IP_ADDRESS = "localhost";
    final int PORT = 8189;

    ArrayList<String> blacklist;


    public void setAuthorized(boolean isAuthorized) {
        this.isAuthorized = isAuthorized;
        if (!isAuthorized) {
            vboxLogin.setVisible(true);
            vboxLogin.setManaged(true);
            vboxLeftMenu.setVisible(false);
            vboxLeftMenu.setManaged(false);
            vboxChat.setManaged(false);
            vboxChat.setVisible(false);
            vboxRightList.setManaged(false);
            vboxRightList.setVisible(false);
        } else {
            vboxLogin.setVisible(false);
            vboxLogin.setManaged(false);
            vboxLeftMenu.setVisible(false);
            vboxLeftMenu.setManaged(false);
            vboxChat.setManaged(true);
            vboxChat.setVisible(true);
            vboxRightList.setManaged(true);
            vboxRightList.setVisible(true);
        }
    }

    public boolean getAuthorized() {
        return isAuthorized;
    }


    public void connect() {
        try {
            socket = new Socket(IP_ADDRESS, PORT);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            setAuthorized(false);
            new Thread(() -> {
                try {
                    while (true) {
                        String str = in.readUTF();
                        if (str.startsWith("/authok")) {
                            setAuthorized(true);
                            generateColor();
                            break;
                        } else {
                            chatArea.appendText(str + "\n");
                        }
                    }
                    getHistory();
                    new Thread(() -> {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        updateBlacklist();
                    }).start();

                    while (true) {
                        String str = in.readUTF();
                        if (str.equals("/serverclosed")) break;
                        if (str.startsWith("/qw ")){
                            String[] tokens = str.split(" ", 3);
                            privTextArea.appendText(tokens[2] + "\n");
                        }

                        if (str.startsWith("/blacklist")) {
                            String[] tokens = str.split(" ");
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    blackList.getItems().clear();
                                    for (int i = 1; i < tokens.length; i++) {
                                        blackList.getItems().add(tokens[i]);
                                    }
                                }
                            });
                            str="";
                        }

                        if (str.startsWith("/clientlist")) {
                            String[] tokens = str.split(" ");
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    clientListRight.getItems().clear();
                                    for (int i = 1; i < tokens.length; i++) {
                                        clientListRight.getItems().add(tokens[i]);
                                    }
                                }
                            });
                        } else {
                            chatArea.appendText(str + "\n");
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    setAuthorized(false);
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMsg() {
        try {
            if (msgField.getText().startsWith("/q")) {
                String[] tokens = msgField.getText().split(" ", 2);
                msgField.clear();
                PrivateMsg(tokens[1]);
            } else {
                out.writeUTF(msgField.getText());
            }

            msgField.clear();
            msgField.requestFocus();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void PrivateMsg(String nickTo) throws IOException {
        Stage privateMsgStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("PrivateMsgForm.fxml"));
        privateMsgStage.setTitle(nickTo);
        //fromNickLabel.setText(nickFrom);
        Scene scene = new Scene(root);
        privateMsgStage.setScene(scene);
        privateMsgStage.show();
        toNickLabel.setText(nickTo);

    }

    public void sendPrivateMsg() {
        try {
            out.writeUTF("/q " + toNickLabel.getText() + " " + privTextField.getText());
            privTextField.clear();
            privTextField.requestFocus();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void tryToAuth(ActionEvent actionEvent) {
        if (socket == null || socket.isClosed()) {
            connect();
        }

        try {
            out.writeUTF("/auth " + loginTextField.getText() + " " + passTextField.getText());
            loginTextField.clear();
            passTextField.clear();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getHistory() {
        try {
            out.writeUTF("/history ");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void generateColor(){
        Random ra = new Random();
        int r, g, b;
        r=ra.nextInt(255);
        g=ra.nextInt(255);
        b=ra.nextInt(255);
        Color col = new Color(r,g,b);
        String hex = "#"+Integer.toHexString(col.getRGB()).substring(2);
        chatArea.setStyle("-fx-text-inner-color: "+hex+";");
    }


    public void updateBlacklist() {
        try {
            out.writeUTF("/updateBlacklist ");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void exitChat(ActionEvent actionEvent) {
    }
}
